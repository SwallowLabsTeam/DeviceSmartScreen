var namespaceorg_1_1swallow__labs_1_1model_1_1Capsule =
[
    [ "Capsule", "d8/dd7/classorg_1_1swallow__labs_1_1model_1_1Capsule_1_1Capsule.html", "d8/dd7/classorg_1_1swallow__labs_1_1model_1_1Capsule_1_1Capsule" ]
];