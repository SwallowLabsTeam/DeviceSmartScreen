var annotated =
[
    [ "org", "db/d96/namespaceorg.html", "db/d96/namespaceorg" ]
];