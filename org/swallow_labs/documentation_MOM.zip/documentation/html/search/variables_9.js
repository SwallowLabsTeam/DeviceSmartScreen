var searchData=
[
  ['nbr_5fbroker',['nbr_broker',['../d6/dfd/classorg_1_1swallow__labs_1_1model_1_1Client_1_1Client.html#ab49af80de652554b9ac58266d0e1b04e',1,'org::swallow_labs::model::Client::Client']]]
];
