var searchData=
[
  ['file_5fstore',['file_store',['../dc/dcb/classorg_1_1swallow__labs_1_1model_1_1EmergencyToolBox_1_1EmergencyToolBox.html#a883bd55e3480f580d1618ddbda8bb123',1,'org::swallow_labs::model::EmergencyToolBox::EmergencyToolBox']]],
  ['frontend',['frontend',['../d9/d39/classorg_1_1swallow__labs_1_1model_1_1Broker_1_1Broker.html#a69f6f1340002bf89c987bec9b095030b',1,'org.swallow_labs.model.Broker.Broker.frontend()'],['../d4/ddc/classorg_1_1swallow__labs_1_1model_1_1BrokerEventManager_1_1BrokerEventManager.html#a480e2a96bea6c0d1337a1086bca05e74',1,'org.swallow_labs.model.BrokerEventManager.BrokerEventManager.frontend()']]]
];
