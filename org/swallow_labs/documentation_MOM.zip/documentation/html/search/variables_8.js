var searchData=
[
  ['message_5flist',['message_list',['../d9/d39/classorg_1_1swallow__labs_1_1model_1_1Broker_1_1Broker.html#a19b75aea4bc3ea205ab3203d0a739a75',1,'org::swallow_labs::model::Broker::Broker']]],
  ['my_5flogger',['my_logger',['../d9/d39/classorg_1_1swallow__labs_1_1model_1_1Broker_1_1Broker.html#a7ece99006b26876febf987fb0929f064',1,'org.swallow_labs.model.Broker.Broker.my_logger()'],['../d8/dd7/classorg_1_1swallow__labs_1_1model_1_1Capsule_1_1Capsule.html#a8d6126628399575afaf2f0371f3ce9c0',1,'org.swallow_labs.model.Capsule.Capsule.my_logger()'],['../d4/d17/classorg_1_1swallow__labs_1_1model_1_1SocketClient_1_1SocketClient.html#adae69670203178ce48555e08638215f7',1,'org.swallow_labs.model.SocketClient.SocketClient.my_logger()']]]
];
