var searchData=
[
  ['backend',['backend',['../d9/d39/classorg_1_1swallow__labs_1_1model_1_1Broker_1_1Broker.html#ae600ed1993c03c4675c4f20177ac9128',1,'org::swallow_labs::model::Broker::Broker']]]
];
