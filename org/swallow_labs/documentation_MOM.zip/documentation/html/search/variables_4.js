var searchData=
[
  ['event',['event',['../db/d30/classorg_1_1swallow__labs_1_1model_1_1RunClient_1_1RunClient.html#aafd1cf4e3096b014856c116b70edd3c5',1,'org::swallow_labs::model::RunClient::RunClient']]]
];
