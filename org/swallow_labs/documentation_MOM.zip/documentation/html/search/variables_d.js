var searchData=
[
  ['tts',['tts',['../d8/dd7/classorg_1_1swallow__labs_1_1model_1_1Capsule_1_1Capsule.html#a46b2d125351092038fd0601b1519b13b',1,'org::swallow_labs::model::Capsule::Capsule']]],
  ['type',['type',['../d8/dd7/classorg_1_1swallow__labs_1_1model_1_1Capsule_1_1Capsule.html#aed9abad78f00038e60e379dcf16a1e83',1,'org::swallow_labs::model::Capsule::Capsule']]]
];
