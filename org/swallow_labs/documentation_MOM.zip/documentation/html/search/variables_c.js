var searchData=
[
  ['sending_5fdate',['sending_date',['../d8/dd7/classorg_1_1swallow__labs_1_1model_1_1Capsule_1_1Capsule.html#ab23e955752bc3568b2ba74b924b34499',1,'org::swallow_labs::model::Capsule::Capsule']]],
  ['sock_5flist',['sock_list',['../d6/dfd/classorg_1_1swallow__labs_1_1model_1_1Client_1_1Client.html#a4cd216428d2ba58070bd3c162425f686',1,'org::swallow_labs::model::Client::Client']]],
  ['socket',['socket',['../d4/d17/classorg_1_1swallow__labs_1_1model_1_1SocketClient_1_1SocketClient.html#aeab713d38e3db149b7d037bec30a3c43',1,'org::swallow_labs::model::SocketClient::SocketClient']]],
  ['sort',['sort',['../d8/dd7/classorg_1_1swallow__labs_1_1model_1_1Capsule_1_1Capsule.html#a61626192eb5683e913927da399d8e779',1,'org::swallow_labs::model::Capsule::Capsule']]],
  ['status',['status',['../d5/d9f/classorg_1_1swallow__labs_1_1model_1_1CapsuleACK_1_1CapsuleACK.html#a0836e64d5e775dd0749b670ae38a9ea3',1,'org::swallow_labs::model::CapsuleACK::CapsuleACK']]],
  ['status_5fcapsule',['status_capsule',['../d8/dd7/classorg_1_1swallow__labs_1_1model_1_1Capsule_1_1Capsule.html#a528b698181018c0cbd08a0979d4728e1',1,'org::swallow_labs::model::Capsule::Capsule']]]
];
