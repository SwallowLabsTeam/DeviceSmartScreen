var searchData=
[
  ['receiving_5fdate',['receiving_date',['../d8/dd7/classorg_1_1swallow__labs_1_1model_1_1Capsule_1_1Capsule.html#a60c8e6cbe6da0be8a3b5932469d1d25f',1,'org::swallow_labs::model::Capsule::Capsule']]]
];
