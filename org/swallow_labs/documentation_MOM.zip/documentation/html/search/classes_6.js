var searchData=
[
  ['sendprocessor',['SendProcessor',['../dc/d71/classorg_1_1swallow__labs_1_1model_1_1SendProcessor_1_1SendProcessor.html',1,'org::swallow_labs::model::SendProcessor']]],
  ['socketclient',['SocketClient',['../d4/d17/classorg_1_1swallow__labs_1_1model_1_1SocketClient_1_1SocketClient.html',1,'org::swallow_labs::model::SocketClient']]]
];
