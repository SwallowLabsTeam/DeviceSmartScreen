var searchData=
[
  ['verif_5fmsg',['verif_msg',['../da/db8/classorg_1_1swallow__labs_1_1model_1_1CapsuleProcessor_1_1CapsuleProcessor.html#a49beb7c5f429df2912aa95c88292e0b3',1,'org::swallow_labs::model::CapsuleProcessor::CapsuleProcessor']]],
  ['verify_5ftts',['verify_tts',['../dc/d71/classorg_1_1swallow__labs_1_1model_1_1SendProcessor_1_1SendProcessor.html#a79157c674c623fcd8c0d65f0182a739d',1,'org::swallow_labs::model::SendProcessor::SendProcessor']]]
];
