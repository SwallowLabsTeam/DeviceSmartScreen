var namespaceorg_1_1swallow__labs_1_1model_1_1Client =
[
    [ "Client", "d6/dfd/classorg_1_1swallow__labs_1_1model_1_1Client_1_1Client.html", "d6/dfd/classorg_1_1swallow__labs_1_1model_1_1Client_1_1Client" ]
];