var namespaceorg_1_1swallow__labs_1_1model_1_1BrokerEventManager =
[
    [ "BrokerEventManager", "d4/ddc/classorg_1_1swallow__labs_1_1model_1_1BrokerEventManager_1_1BrokerEventManager.html", "d4/ddc/classorg_1_1swallow__labs_1_1model_1_1BrokerEventManager_1_1BrokerEventManager" ]
];