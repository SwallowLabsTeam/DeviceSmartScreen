var classorg_1_1swallow__labs_1_1model_1_1BrokerData_1_1BrokerData =
[
    [ "__init__", "d1/db6/classorg_1_1swallow__labs_1_1model_1_1BrokerData_1_1BrokerData.html#ac4d0b809be4492279d88206f03fe8e70", null ],
    [ "address", "d1/db6/classorg_1_1swallow__labs_1_1model_1_1BrokerData_1_1BrokerData.html#a5e9fd1b4dd1ca682d73cb2c0d8f18095", null ],
    [ "port", "d1/db6/classorg_1_1swallow__labs_1_1model_1_1BrokerData_1_1BrokerData.html#a7267e34808592f541332ee87dd3f0202", null ]
];