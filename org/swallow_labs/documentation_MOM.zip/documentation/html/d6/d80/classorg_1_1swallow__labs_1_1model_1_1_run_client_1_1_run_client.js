var classorg_1_1swallow__labs_1_1model_1_1_run_client_1_1_run_client =
[
    [ "__init__", "d6/d80/classorg_1_1swallow__labs_1_1model_1_1_run_client_1_1_run_client.html#a64ea60db666418dd0077961550e5eecc", null ],
    [ "pull_routine", "d6/d80/classorg_1_1swallow__labs_1_1model_1_1_run_client_1_1_run_client.html#ae6e6d144505b6cf61b3a0bd9a27b7ee1", null ],
    [ "push_routine", "d6/d80/classorg_1_1swallow__labs_1_1model_1_1_run_client_1_1_run_client.html#ae777d97e02e001fabf8c152f99cd0bf0", null ],
    [ "remove_capsule", "d6/d80/classorg_1_1swallow__labs_1_1model_1_1_run_client_1_1_run_client.html#ac2ef4486a4daba04faabab3e91c317ad", null ],
    [ "event", "d6/d80/classorg_1_1swallow__labs_1_1model_1_1_run_client_1_1_run_client.html#aafd1cf4e3096b014856c116b70edd3c5", null ],
    [ "id_client", "d6/d80/classorg_1_1swallow__labs_1_1model_1_1_run_client_1_1_run_client.html#a876ad6e3b9f3e77dd2862a89b6b920a3", null ],
    [ "id_event", "d6/d80/classorg_1_1swallow__labs_1_1model_1_1_run_client_1_1_run_client.html#aa3f3af8033016ab341f4507385e00784", null ],
    [ "list_address", "d6/d80/classorg_1_1swallow__labs_1_1model_1_1_run_client_1_1_run_client.html#ad4854628e4a05a680f45b9bd47de74d2", null ]
];