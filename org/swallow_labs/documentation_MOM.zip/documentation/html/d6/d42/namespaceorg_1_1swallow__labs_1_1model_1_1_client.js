var namespaceorg_1_1swallow__labs_1_1model_1_1_client =
[
    [ "Client", "d1/d7f/classorg_1_1swallow__labs_1_1model_1_1_client_1_1_client.html", "d1/d7f/classorg_1_1swallow__labs_1_1model_1_1_client_1_1_client" ]
];