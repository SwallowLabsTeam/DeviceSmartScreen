var classorg_1_1swallow__labs_1_1model_1_1BrokerEventManager_1_1BrokerEventManager =
[
    [ "__init__", "d4/ddc/classorg_1_1swallow__labs_1_1model_1_1BrokerEventManager_1_1BrokerEventManager.html#ac34478e56b6178282ec27bec3f65d6cf", null ],
    [ "start", "d4/ddc/classorg_1_1swallow__labs_1_1model_1_1BrokerEventManager_1_1BrokerEventManager.html#a949e31cb1e893651c979a2b40fdec2b5", null ],
    [ "frontend", "d4/ddc/classorg_1_1swallow__labs_1_1model_1_1BrokerEventManager_1_1BrokerEventManager.html#a480e2a96bea6c0d1337a1086bca05e74", null ],
    [ "id_frontend", "d4/ddc/classorg_1_1swallow__labs_1_1model_1_1BrokerEventManager_1_1BrokerEventManager.html#addf55d2820f86711ae0629019783ac11", null ],
    [ "poller", "d4/ddc/classorg_1_1swallow__labs_1_1model_1_1BrokerEventManager_1_1BrokerEventManager.html#a7f7421f757762687c2f7dccda8e94d85", null ]
];