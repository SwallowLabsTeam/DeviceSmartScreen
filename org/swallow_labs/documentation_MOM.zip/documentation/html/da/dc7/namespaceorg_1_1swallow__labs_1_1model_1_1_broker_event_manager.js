var namespaceorg_1_1swallow__labs_1_1model_1_1_broker_event_manager =
[
    [ "BrokerEventManager", "da/d56/classorg_1_1swallow__labs_1_1model_1_1_broker_event_manager_1_1_broker_event_manager.html", "da/d56/classorg_1_1swallow__labs_1_1model_1_1_broker_event_manager_1_1_broker_event_manager" ]
];