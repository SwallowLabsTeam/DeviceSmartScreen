var classorg_1_1swallow__labs_1_1model_1_1_broker_event_manager_1_1_broker_event_manager =
[
    [ "__init__", "da/d56/classorg_1_1swallow__labs_1_1model_1_1_broker_event_manager_1_1_broker_event_manager.html#ac34478e56b6178282ec27bec3f65d6cf", null ],
    [ "start", "da/d56/classorg_1_1swallow__labs_1_1model_1_1_broker_event_manager_1_1_broker_event_manager.html#a949e31cb1e893651c979a2b40fdec2b5", null ],
    [ "frontend", "da/d56/classorg_1_1swallow__labs_1_1model_1_1_broker_event_manager_1_1_broker_event_manager.html#a480e2a96bea6c0d1337a1086bca05e74", null ],
    [ "id_frontend", "da/d56/classorg_1_1swallow__labs_1_1model_1_1_broker_event_manager_1_1_broker_event_manager.html#addf55d2820f86711ae0629019783ac11", null ],
    [ "poller", "da/d56/classorg_1_1swallow__labs_1_1model_1_1_broker_event_manager_1_1_broker_event_manager.html#a7f7421f757762687c2f7dccda8e94d85", null ]
];