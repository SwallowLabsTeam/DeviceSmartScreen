var classorg_1_1swallow__labs_1_1model_1_1_broker_data_1_1_broker_data =
[
    [ "__init__", "classorg_1_1swallow__labs_1_1model_1_1_broker_data_1_1_broker_data.html#ac4d0b809be4492279d88206f03fe8e70", null ],
    [ "address", "classorg_1_1swallow__labs_1_1model_1_1_broker_data_1_1_broker_data.html#a5e9fd1b4dd1ca682d73cb2c0d8f18095", null ],
    [ "port", "classorg_1_1swallow__labs_1_1model_1_1_broker_data_1_1_broker_data.html#a7267e34808592f541332ee87dd3f0202", null ]
];