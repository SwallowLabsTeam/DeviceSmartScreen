var classorg_1_1swallow__labs_1_1model_1_1_capsule_a_c_k_1_1_capsule_a_c_k =
[
    [ "__init__", "dc/d7f/classorg_1_1swallow__labs_1_1model_1_1_capsule_a_c_k_1_1_capsule_a_c_k.html#adef5c6fa853ccd00b47351dc6593e204", null ],
    [ "get_id_capsule", "dc/d7f/classorg_1_1swallow__labs_1_1model_1_1_capsule_a_c_k_1_1_capsule_a_c_k.html#abe7270611aea2098362a5d6a26c2a4f4", null ],
    [ "get_status", "dc/d7f/classorg_1_1swallow__labs_1_1model_1_1_capsule_a_c_k_1_1_capsule_a_c_k.html#a6a4ed2f6044656fa1e1e0b238dfc1c88", null ],
    [ "set_id_capsule", "dc/d7f/classorg_1_1swallow__labs_1_1model_1_1_capsule_a_c_k_1_1_capsule_a_c_k.html#a100f09ea23b957568fc02db0755f095b", null ],
    [ "set_status", "dc/d7f/classorg_1_1swallow__labs_1_1model_1_1_capsule_a_c_k_1_1_capsule_a_c_k.html#a28c38279b40e13e8f24f053b3e2f863c", null ],
    [ "id_capsule", "dc/d7f/classorg_1_1swallow__labs_1_1model_1_1_capsule_a_c_k_1_1_capsule_a_c_k.html#a5e9e3ae752888459429ad5fa12d2dffa", null ],
    [ "status", "dc/d7f/classorg_1_1swallow__labs_1_1model_1_1_capsule_a_c_k_1_1_capsule_a_c_k.html#a0836e64d5e775dd0749b670ae38a9ea3", null ]
];