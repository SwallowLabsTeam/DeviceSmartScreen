var namespaceorg_1_1swallow__labs_1_1model_1_1CapsuleProcessor =
[
    [ "CapsuleProcessor", "da/db8/classorg_1_1swallow__labs_1_1model_1_1CapsuleProcessor_1_1CapsuleProcessor.html", "da/db8/classorg_1_1swallow__labs_1_1model_1_1CapsuleProcessor_1_1CapsuleProcessor" ]
];